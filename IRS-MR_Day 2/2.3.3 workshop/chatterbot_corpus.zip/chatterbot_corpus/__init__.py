"""
A machine readable multilingual dialog corpus.
"""

__version__ = '1.2.0'
__author__ = 'Gunther Cox'
__email__ = 'gunthercx@gmail.com'
__url__ = 'https://github.com/gunthercox/chatterbot-corpus'
